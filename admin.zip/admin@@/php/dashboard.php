<?php
function mainProcess()
{
	$str.='
	<div class="row">
		<div class="col-lg-12">
			<h2 class="page-header">Administrator Panel</a>
		</div>
		<div class="col-lg-12">
			<div class="alert alert-success">
                                Chào mừng bạn đến với Administrator panel...
            </div>
		</div>
	</div>
	
	';
	return $str;	
}


?>